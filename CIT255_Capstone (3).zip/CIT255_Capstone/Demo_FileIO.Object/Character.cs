﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_FileIO
{
    public class Character
    {
        //public enum GenderType { MALE, FEMALE }

        public int Id { get; set; }
        public string Title { get; set; }
        public int AveScore { get; set; }
        public int Sales { get; set; }


        public string FullName()
        {
            if (Title != "")
            {
                return Title;
            }
            else
            {
                return Title;
            }
        }

        public int FullNameOne()
        {
            if (Title != "")
            {
                return AveScore;
            }
            else
            {
                return AveScore;
            }
        }

        public int FullNameTwo()
        {
            if (Title != "")
            {
                return Sales;
            }
            else
            {
                return Sales;
            }
        }
    }
}
