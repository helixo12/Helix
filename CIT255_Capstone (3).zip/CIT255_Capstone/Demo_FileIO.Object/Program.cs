﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_FileIO
{
    class Program
    {

        //private static object character;
        private static string userResponse;

        static void Main(string[] args)
        {
            string dataPath = @"Data\Data.csv";

            //
            // debug: save seed data to the data file
            //
            //SeedDataFile(dataPath);

            DisplayOpeningScreen();
            DisplayMenu(dataPath);
            DisplayClosingScreen();
        }

        /// <summary>
        /// display menu and process user menu choices
        /// </summary>
        static void DisplayMenu(string dataPath)
        {
            string menuChoice;
            bool exiting = false;
            List<Character> characters = null;

            //
            // debug: initialize the character list with character objects
            //
            characters = InitializeListOfCharacters();

            while (!exiting)
            {
                DisplayHeader("Main Menu");

                Console.WriteLine("\ta) Display All Games");
                Console.WriteLine("\tb) Add a Game");
                Console.WriteLine("\tc) Remove a Game");
                Console.WriteLine("\td) Edit a Game");
                Console.WriteLine("\te) Display Game Info");
                Console.WriteLine("\tf) Save Games to a File");
                Console.WriteLine("\tg) Load Games from a File");
                Console.WriteLine("\tq) Quit");
                Console.WriteLine();
                Console.Write("\tEnter Choice:");
                menuChoice = Console.ReadLine();

                switch (menuChoice.ToLower())
                {
                    case "a":
                        DisplayAllCharacters(characters);
                        break;

                    case "b":
                        DisplayAddCharacter(characters);
                        break;

                    case "c":
                        DisplayDeleteCharacter(characters);
                        break;

                    case "d":
                        DisplayEditCharacter(characters);
                        break;

                    case "e":
                        DisplayCharacterDetail(characters);
                        break;

                    case "f":
                        DisplaySaveCharactersToFile(dataPath, characters);
                        break;

                    case "g":
                        characters = DisplayLoadCharactersFromFile(dataPath);
                        break;

                    case "q":
                        exiting = true;
                        break;

                    default:
                        break;
                }
            }
        }


        /// <summary>
        /// display all of the properties of a character
        /// </summary>
        /// <param name="characters">list of characters</param>
        private static void DisplayCharacterDetail(List<Character> characters)
        {
            DisplayHeader("Game Information");

            Console.Write("Enter Id of Game:");
            int.TryParse(Console.ReadLine(), out int id);

            Character character = new Character();
            character = characters.FirstOrDefault(c => c.Id == id);

            Console.WriteLine("Current Game Information");
            DisplayCharacterDetailTable(character);
            Console.WriteLine();

            DisplayContinuePrompt();
        }

        /// <summary>
        /// user adds a character
        /// </summary>
        /// <param name="characters">list of characters</param>
        private static void DisplayAddCharacter(List<Character> characters)
        {
            Character character = new Character();

            DisplayHeader("Add a Game");

            Console.Write("Enter Game Title:");

            character.Title = Console.ReadLine();
            Console.Write("Enter Average Score:");
            int.TryParse(Console.ReadLine(), out int aveScore);
            character.AveScore = aveScore;
            Console.Write("Enter Sales Numbers:");
            int.TryParse(Console.ReadLine(), out int sales);
            character.Sales = sales;

            Console.WriteLine();
            Console.WriteLine("New Game To Add");
            Console.WriteLine($"\tId: {character.Id}");
            Console.WriteLine($"\tFirst Name: {character.Title}");
            Console.WriteLine($"\tLast Name: {character.AveScore}");
            Console.WriteLine($"\tAge: {character.Sales}");

            characters.Add(character);

            DisplayContinuePrompt();
        }

        /// <summary>
        /// user deletes a character
        /// </summary>
        /// <param name="characters">list of characters</param>
        private static void DisplayDeleteCharacter(List<Character> characters)
        {
            DisplayHeader("Remove a Game");

            Console.Write("Enter Id of Game to Delete:");
            int.TryParse(Console.ReadLine(), out int id);


            Character character = characters.FirstOrDefault(c => c.Id == id);

            characters.Remove(character);

            DisplayContinuePrompt();
        }

        /// <summary>
        /// user edits a character
        /// </summary>
        /// <param name="characters">list of characters</param>
        private static void DisplayEditCharacter(List<Character> characters)
        {
            DisplayHeader("Edit a Game");

            Console.Write("Enter Id of Game to Update:");
            int.TryParse(Console.ReadLine(), out int id);

            Character character = new Character();
            character = characters.FirstOrDefault(c => c.Id == id);

            if (character != null)
            {
                DisplayHeader("Game Detail");
                Console.WriteLine("Current Game Information");
                DisplayCharacterDetailTable(character);
                Console.WriteLine();

                Console.WriteLine("Update each field or use the Enter key to keep the current information.");
                Console.WriteLine();

                Console.Write("Enter Game Title:");
                userResponse = Console.ReadLine();
                if (userResponse != "")
                {
                    character.Title = userResponse;
                }

                Console.Write("Enter Average Score:");
                userResponse = Console.ReadLine();
                if (userResponse != "")
                {
                    int.TryParse(userResponse, out int aveScore);
                    character.AveScore = aveScore;

                }

                Console.Write("Enter Sales:");
                userResponse = Console.ReadLine();
                if (userResponse != "")
                {
                    int.TryParse(userResponse, out int sales);
                    character.Sales = sales;
                    
                }

                Character delete = characters.FirstOrDefault(c => c.Id == id);
                characters.Remove(delete);
                characters.Add(character);
                DisplayContinuePrompt(); 
            }
        }

        /// <summary>
        /// save character list to the data file
        /// </summary>
        /// <param name="dataPath">data path</param>
        /// <param name="characters">list of characters</param>
        private static void DisplaySaveCharactersToFile(string dataPath, List<Character> characters)
        {
            DisplayHeader("Save Games to File");

            Console.WriteLine($"\tThe list of games will be saved to '{dataPath}'.");
            Console.WriteLine("\t\tPress any key to continue.");
            Console.ReadKey();

            //
            // try to write the list of characters to the file
            //
            try
            {
                WriteCharactersToCsvFile(dataPath, characters);
                Console.WriteLine("\tThe games were successfully saved to the file.");
            }
            catch (Exception e)// catch any exception thrown by the write method
            {
                Console.WriteLine("\tThe following error occurred when writing to the file.");
                Console.WriteLine(e.Message);
            }

            DisplayContinuePrompt();
        }

        /// <summary>
        /// load character list from data file
        /// </summary>
        /// <param name="dataPath">data path</param>
        /// <returns>list of characters</returns>
        private static List<Character> DisplayLoadCharactersFromFile(string dataPath)
        {
            List<Character> characters = new List<Character>();

            DisplayHeader("Load Games from File");

            Console.WriteLine($"\tThe list of games will be loaded from '{dataPath}'.");
            Console.WriteLine("\t\tPress any key to continue.");
            Console.ReadKey();

            //
            // try to read the characters from the data file into a list
            //
            try
            {
                characters = ReadCharactersFromCsvFile(dataPath);
                Console.WriteLine("/tThe games were successfully loaded from the file.");
            }
            catch (Exception e) // catch any exception thrown by the read method
            {
                Console.WriteLine("/tThe following error occurred when reading from the file.");
                Console.WriteLine(e.Message);
            }

            DisplayContinuePrompt();

            return characters;
        }

        /// <summary>
        /// display all characters
        /// </summary>
        /// <param name="characters">list of characters</param>
        private static void DisplayAllCharacters(List<Character> characters)
        {
            DisplayHeader("All Game Stats");

            if (characters != null)
            {
                foreach (Character character in characters)
                {
                    Console.WriteLine($"\t{character.FullName()}");
                    Console.WriteLine($"\t{character.FullNameOne()}");
                    Console.WriteLine($"\t{character.FullNameTwo()}");
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("\tThere are currently no games available.");
            }

            DisplayContinuePrompt();
        }

        /// <summary>
        /// load seed data into data file
        /// </summary>
        static void SeedDataFile(string dataPath)
        {
            WriteCharactersToCsvFile(dataPath, InitializeListOfCharacters());
        }

        /// <summary>
        /// initialize a list of seed characters
        /// </summary>
        /// <returns>list of characters</returns>
        static List<Character> InitializeListOfCharacters()
        {
            List<Character> characters = new List<Character>();

            Character character1 = new Character();
            character1.Id = 1;
            character1.Title = "The Legend of Zelda: Breath of the Wild";
            character1.AveScore = 97;
            character1.Sales = 11700000;
            characters.Add(character1);

            Character character2 = new Character();
            character2.Id = 2;
            character2.Title = "Super Mario Odyssey";
            character2.AveScore = 97;
            character2.Sales = 12170000;
            characters.Add(character2);

            return characters;
        }

        /// <summary>
        /// display all character properties
        /// </summary>
        /// <param name="characters">character object</param>
        static void DisplayCharacterDetail(Character character)
        {
            Console.WriteLine();
            Console.WriteLine($"\tId: {character.Id}");
            Console.WriteLine($"\tGame Title: {character.Title}");
            Console.WriteLine($"\tAverage Score: {character.AveScore}");
            Console.WriteLine($"\tSales Numbers: {character.Sales}");
            Console.WriteLine();
        }

        /// <summary>
        /// save list of characters to a file
        /// </summary>
        /// <param name="characterClassLIst">list of characters</param>
        /// <param name="dataPath">data path</param>
        static void WriteCharactersToCsvFile(string dataPath, List<Character> characterClassLIst)
        {
            string characterString;

            List<string> characterStringList = new List<string>();

            //
            // build the list to write to the text file line by line
            //
            foreach (var character in characterClassLIst)
            {
                characterString =
                    character.Id + "," +
                    character.Title + "," +
                    character.AveScore + "," +
                    character.Sales;


                characterStringList.Add(characterString);
            }

            //
            // write the list of strings (characters) to the data file
            //
            try
            {
                File.WriteAllLines(dataPath, characterStringList);
            }
            catch (Exception) // throw any exception up to the calling method
            {
                throw;
            }

        }

        private static void DisplayCharacterDetailTable(Character character)
        {
            Console.WriteLine($"\tId: {character.Id}");
            Console.WriteLine($"\tTitle: {character.Title}");
            Console.WriteLine($"\tAverage Score: {character.AveScore}");
            Console.WriteLine($"\tSales: {character.Sales}");
        }

        /// <summary>
        /// load all characters from a file
        /// </summary>
        /// <param name="dataFile">data path</param>
        /// <returns>list of characters</returns>
        static List<Character> ReadCharactersFromCsvFile(string dataFile)
        {
            const char delineator = ',';

            List<string> characterStringList = new List<string>();
            List<Character> characterObjectList = new List<Character>();
            //Character tempCharacter = new Character();

            //
            // read each line and put it into an array and convert the array to a list
            //
            try
            {
                characterStringList = File.ReadAllLines(dataFile).ToList();
            }
            catch (Exception) // throw any exception up to the calling method
            {
                throw;
            }

            //
            // create character object for each line of data read and fill in the property values
            //
            foreach (string characterString in characterStringList)
            {
                Character tempCharacter = new Character();

                // use the Split method and the delineator on the array to separate each property into an array of properties
                string[] properties = characterString.Split(delineator);

                tempCharacter.Id = Convert.ToInt32(properties[0]);
                tempCharacter.Title = properties[1];
                tempCharacter.AveScore = Convert.ToInt32(properties[2]);
                tempCharacter.Sales = Convert.ToInt32(properties[3]);

                characterObjectList.Add(tempCharacter);
            }

            return characterObjectList;
        }

        #region HELPER METHODS

        /// <summary>
        /// display opening screen
        /// </summary>
        static void DisplayOpeningScreen()
        {
            Console.Clear();

            Console.WriteLine();
            Console.WriteLine("\t\tWelcome to Flintstone Characters Database");
            Console.WriteLine();

            DisplayContinuePrompt();
        }

        /// <summary>
        /// display closing screen
        /// </summary>
        static void DisplayClosingScreen()
        {
            Console.Clear();

            Console.WriteLine();
            Console.WriteLine("\t\tThanks for using Flintstone Characters Database.");
            Console.WriteLine();

            Console.WriteLine("Press any key to exit.");
            Console.ReadKey();
        }

        /// <summary>
        /// display continue prompt
        /// </summary>
        static void DisplayContinuePrompt()
        {
            Console.CursorVisible = false;
            Console.WriteLine();
            Console.WriteLine("\tPress any key to continue.");
            Console.ReadKey();
            Console.CursorVisible = true;
        }

        /// <summary>
        /// display header
        /// </summary>
        static void DisplayHeader(string headerTitle)
        {
            Console.Clear();
            Console.WriteLine();
            Console.WriteLine("\t\t" + headerTitle);
            Console.WriteLine();
        }

        #endregion


    }
}
